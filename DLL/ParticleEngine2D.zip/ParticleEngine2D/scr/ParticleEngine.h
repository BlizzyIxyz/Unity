#ifndef PARTICLE_ENGINE_H
#define PARTICLE_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct {
        float x, y;
    } Vector2;

    void update_particles_2D(
        Vector2* positions,
        Vector2* velocities,
        int count,
        Vector2 target,
        float speed,
        float dt
    );

#ifdef __cplusplus
}
#endif

#endif