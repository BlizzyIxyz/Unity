#include "ParticleEngine.h"
#include "pch.h"
#include <math.h>

typedef struct {
	float x, y;
} Vector2;

static void normalize(Vector2* v) {
	float len_sq = v->x * v->x + v->y * v->y;
	if (len_sq > 1e-6f) {
		float len_inv = 1.0f / sqrtf(len_sq);
		v->x *= len_inv;
		v->y *= len_inv;
	}
	else {
		v->x = v->y = 0.0f;
	}
}

__declspec(dllexport) void update_particles_2D(
	Vector2* positions,
	Vector2* velocities,
	int count,
	Vector2 target,
	float speed,
	float dt
) {
	for (int i = 0; i < count; ++i) {
		Vector2 dir = {
			target.x - positions[i].x,
			target.y - positions[i].y
		};
		normalize(&dir);

		velocities[i].x += dir.x * speed;
		velocities[i].y += dir.y * speed;

		positions[i].x += velocities[i].x * dt;
		positions[i].y += velocities[i].y * dt;
	}
}