#include "pch.h"
#include <stdint.h>
#include <stdlib.h>
#include <windows.h>
#include <stdio.h>
#include <objbase.h>
#include <shlobj.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "shell32.lib")

// External SHA-256 implementation
extern void sha256(const uint8_t* message, size_t len, uint8_t hash[32]);

// Static salt embedded in the DLL
static unsigned char DLLSalt[] = {
    0x46, 0xd6, 0xea, 0x9f, 0x5f, 0x3c, 0x67, 0x16,
    0x36, 0x8c, 0x69, 0xac, 0x72, 0x82, 0x12, 0x5d,
    0xf6, 0xfe, 0x5f, 0xec, 0x00, 0xd9, 0x99, 0x72,
    0xab, 0x0a, 0x0c, 0xa7, 0xdb, 0x37, 0x56, 0x2f
};

/**
 * Retrieves or creates a persistent installation GUID stored in LocalAppData.
 * The GUID is saved to a file to ensure consistency across runs.
 */
static GUID get_or_create_install_guid() {
    GUID guid = { 0 };
    char filepath[MAX_PATH] = { 0 };

    // Get the LocalAppData path (e.g., C:\Users\...\AppData\Local)
    if (FAILED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, filepath))) {
        return guid; // Return zero-initialized GUID on failure
    }

    // Construct directory path: <LocalAppData>\MCS\CC
    strcat_s(filepath, MAX_PATH, "\\MCS\\CC");
    CreateDirectoryA(filepath, NULL);

    // Construct full file path: <LocalAppData>\MCS\CC\InstallGUID.dat
    strcat_s(filepath, MAX_PATH, "\\InstallGUID.dat");

    // Try to read existing GUID from file
    FILE* file;
    errno_t err = fopen_s(&file, filepath, "rb");
    if (err == 0 && file) {
        if (fread(&guid, 1, sizeof(GUID), file) == sizeof(GUID)) {
            fclose(file);
            return guid;
        }
        fclose(file);
    }

    // If no valid GUID was read, generate a new one
    CoCreateGuid(&guid);

    // Save the newly created GUID to the file
    err = fopen_s(&file, filepath, "wb");
    if (err == 0 && file) {
        fwrite(&guid, 1, sizeof(GUID), file);
        fclose(file);
    }

    return guid;
}

/**
 * Generates a device-specific salt based on hardware and installation info.
 * Uses volume serial number, CPU info, and installation GUID.
 * Returns a dynamically allocated 32-byte SHA-256 hash (must be freed by caller).
 * Returns NULL on allocation failure.
 */
static uint8_t* get_device_salt() {
    uint8_t* salt = (uint8_t*)malloc(32);
    if (!salt) return NULL;

    HKEY hKey;
    char machineGuid[64] = { 0 };
    DWORD size = sizeof(machineGuid);

    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
        "SOFTWARE\\Microsoft\\Cryptography",
        0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExA(hKey, "MachineGuid", NULL, NULL, (LPBYTE)machineGuid, &size) != ERROR_SUCCESS) {
            strcpy_s(machineGuid, sizeof(machineGuid), "UNKNOWN");
        }
        RegCloseKey(hKey);
    }
    else {
        strcpy_s(machineGuid, sizeof(machineGuid), "UNKNOWN");
    }

    // Hash the MachineGuid string
    sha256((const uint8_t*)machineGuid, strlen(machineGuid), salt);

    return salt;
}

/**
 * Exports a function to compute a final key by combining three salts:
 * - Application salt (input)
 * - Device salt (generated from hardware/installation)
 * - DLL salt (embedded constant)
 * Output is a 32-byte SHA-256 hash.
 */
__declspec(dllexport) void getfinalkey(uint8_t hash_out[32], uint8_t applicationsalt[32]) {
    uint8_t* devicesalt = get_device_salt();
    if (!devicesalt) {
        // Zero output on failure
        memset(hash_out, 0, 32);
        return;
    }

    // Input buffer: application salt (32) + device salt (32) + DLL salt (32) = 96 bytes
    uint8_t input[96];
    memcpy(input + 0, applicationsalt, 32);
    memcpy(input + 32, devicesalt, 32);
    memcpy(input + 64, DLLSalt, 32);

    // Final SHA-256 hash
    sha256(input, 96, hash_out);

    // Clean up dynamically allocated memory
    free(devicesalt);
}