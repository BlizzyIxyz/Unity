using System;
using TMPro;
using Zenject;

public class Display : IInitializable, IDisposable
{
    private TMP_Text _text;
    private Counter _counter;

    [Inject]
    public void Construct(TMP_Text text, Counter counter)
    {
        _text = text;
        _counter = counter;
    }

    public void Initialize()
    {
        _counter.OnCounterUpdate += UpdateDisplay;
        _text.text = "0";
    }

    private void UpdateDisplay(int count)
    {
        _text.text = count.ToString();
    }

    public void Dispose()
    {
        _counter.OnCounterUpdate -= UpdateDisplay;
    }
}
