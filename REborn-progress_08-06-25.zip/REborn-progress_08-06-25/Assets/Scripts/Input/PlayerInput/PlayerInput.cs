using System;
using Zenject;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInput : IInput, IInitializable, IDisposable
{
    public event Action<Vector2> OnMove;

    private InputSystem_Actions inputActions;

    public void Initialize()
    {
        inputActions = new InputSystem_Actions();

        inputActions.Player.Move.performed += ApplyMovementDirection;

        inputActions.Enable();
    }

    private void ApplyMovementDirection(InputAction.CallbackContext ctx)
    {
        OnMove.Invoke(ctx.ReadValue<Vector2>());
    }

    public void Dispose()
    {
        inputActions.Disable();

        inputActions.Player.Move.performed -= ApplyMovementDirection;

        inputActions.Dispose();
    }
}