using System;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

public class Counter : IDisposable, IInitializable
{
    public event Action<int> OnCounterUpdate;

    private CoinSpawner _coinSpawner;

    private int CoinsPickedUp;

    private List<GameObject> _publishers = new();

    [Inject]
    public void Construct(CoinSpawner coinSpawner)
    {
        _coinSpawner = coinSpawner;
    }

    public void Initialize()
    {
        _coinSpawner.OnCoinSpawn += AddPublisher;
    }

    private void AddPublisher(GameObject other)
    {
        // ��� ��������? �� � �����, ��� ��� �� �����? ������� ����� ��� ��...
        _publishers.Add(other);
        other.GetComponent<CoinPickUp>().OnPickUp += AddCoin;
    }

    private void AddCoin(GameObject other)
    { 
        CoinsPickedUp++;
        other.GetComponent<CoinPickUp>().OnPickUp -= AddCoin;
        OnCounterUpdate.Invoke(CoinsPickedUp);
        _publishers.Remove(other);
    }

    public void Dispose()
    {
        foreach (GameObject other in _publishers)
            other.GetComponent<CoinPickUp>().OnPickUp -= AddCoin;
        _coinSpawner.OnCoinSpawn -= AddPublisher;
    }
}