using System;
using UnityEngine;
using Zenject;

public class PlayerMovement : MonoBehaviour, IInitializable, IDisposable
{
    private IInput _input;
    private PlayerSO _playerSO;

    [Inject]
    public void Construct(IInput input, PlayerSO playerSO)
    {
        _input = input;
        _playerSO = playerSO;
    }

    public void Initialize()
    {
        _input.OnMove += Move;
    }

    private void Move(Vector2 dir)
    {
        transform.Translate(new Vector3(dir.x, dir.y, 0f));
    }

    public void Dispose()
    {
        _input.OnMove -= Move;
    }
}
