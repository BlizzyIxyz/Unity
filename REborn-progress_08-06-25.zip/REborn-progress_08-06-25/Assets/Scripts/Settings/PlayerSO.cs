using UnityEngine;

[CreateAssetMenu(menuName = "Settings/Player")]
public class PlayerSO : ScriptableObject
{
    [field: SerializeField] public float PlayerSpeed { get; private set; }
}
