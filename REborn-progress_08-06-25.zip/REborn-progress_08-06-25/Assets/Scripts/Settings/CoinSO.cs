using UnityEngine;

[CreateAssetMenu(menuName = "Settings/Coin")]
public class CoinSO : ScriptableObject
{
    [field: SerializeField] public int MaxCoinsOnScene { get; private set; }
    [field: SerializeField] public int CoinSpawnDelay { get; private set; }
    [field: SerializeField] public int Nothing { get; private set; }
}
