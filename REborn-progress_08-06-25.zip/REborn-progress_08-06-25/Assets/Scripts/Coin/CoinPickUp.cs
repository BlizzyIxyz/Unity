using System;
using UnityEngine;
using Zenject;

public class CoinPickUp : MonoBehaviour, IPickable
{
    public event Action<GameObject> OnPickUp;

    private CoinPool _coinPool;

    [Inject]
    public void Construct(CoinPool coinPool)
    {
        _coinPool = coinPool;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerPlaceholder>() != null)
        {
            OnPickUp?.Invoke(gameObject);

            _coinPool.PoolCoin(gameObject);
            Debug.Log("Coin picked up");
        }
    }
}
