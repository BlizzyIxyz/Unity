using Zenject;

public class CoinFactory : PlaceholderFactory<CoinPickUp> { }